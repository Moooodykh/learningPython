import csv

# Open the csv and create a reader object
csvFile = open('ratings.csv', 'r')
csvReader = csv.reader(csvFile, delimiter=',', quotechar='"')

# Read the csv file into a list of rows
ratings = []
for row in csvReader:
    ratings.append(row)

# Print the first row
print(ratings[0])
print()

# Map list to floating values
floatValues = map(float,ratings[0]) # Alt. [float(x) for x in ratings[0]]

# Calculate and print the sum
sumOfValues = sum(floatValues)
print('Sum=', sumOfValues)
#print('Sum=', sum(map(float,ratings[0]))) # All can be done in the print-cmd


# Calculate mean and print the sum
mean = sumOfValues/len(ratings[0])
print('Mean=', mean)




