import csv

# Open the csv and create a reader object
csvFile = open('ratings.csv', 'r')
csvReader = csv.reader(csvFile, delimiter=',', quotechar='"')

# Read the csv file into a list of rows
ratings = []
for row in csvReader:
    ratings.append(row)

# Print the first row
print(ratings[0])

print(len(ratings))

