import polyplotter

def main():
    # Prepare the display object
    plotter = polyplotter.PolyPlotter()


    # Read and parse the points from the input file
    # Build the list of polygons, sorted in z-order   
    

    # Draw polygons
    plotter.plot()

main()

