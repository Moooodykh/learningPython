# -*- coding: utf-8 -*-
"""
Created on Wed May 23 13:01:49 2018

@author: dander12
"""


import polyplotter
import time

def getlastelem(x):
    return x[-1]

def main():
    # Prepare the display object
    plotter = polyplotter.PolyPlotter()

    # Read and parse the points from the input file
    # Build the list of polygons, sorted in z-order  
    
    [plotter.add_poly(p[0:2], p[2:4], p[4:6]) for p in sorted([[float(y) for y in x.split()] for x in open('polygons.txt', 'r')], key=getlastelem)]
    
    # Draw polygons
    plotter.plot()
    
main()
   