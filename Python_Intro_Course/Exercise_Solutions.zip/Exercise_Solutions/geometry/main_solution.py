import polyplotter
import operator


def main():
    
    # Prepare the display object
    plotter = polyplotter.PolyPlotter()
            
    # Read and parse the points from the input file
    polyFile = open('polygons.txt', 'r')    
    
    polys = []
    for row in polyFile: 
        print(row, type(row), '\n')
        # Convert string into list (removes white-space)
        vList = row.split() 
        print(vList, '\n')
        
        # Covert strings into float
        vList = [float(x) for x in vList] # or list(map(float, vList))
        
        # Append new list
        polys.append(vList)


    # Close file    
    polyFile.close()
    
    print('\nPolys before sort:\n', polys)
    
    # Build the list of polygons, sorted in z-order
    polys.sort(key=getlastelem) 
    
    # Alternative using module 'operator'
    #sorted_polys = sorted(polys, key=operator.itemgetter(-1)) 
    
    print('\nPolys after sort:\n', polys)
    
    for poly in polys:
        p1 = poly[0:2]
        p2 = poly[2:4]
        p3 = poly[4:6]
        plotter.add_poly(p1, p2, p3)
    
    # Draw polygons
    plotter.plot()
    
   
def getlastelem(x):
    return x[-1]



main()
