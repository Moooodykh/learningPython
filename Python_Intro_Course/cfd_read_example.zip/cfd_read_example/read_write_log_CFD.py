# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 10:32:57 2019

@author: dander12
"""

import pandas as pd

f = open('ContOper_SM_1000rpm.log', 'r')

d = {'Torque' : [],
     'Magnet_Temp': [],
     'Winding_Temp': []}

torque = 0
m_temp = 0
w_temp = 0

for row in f.readlines():
    
    if 'The part temperatures at' in row:
        torque = float(row.split('rpm,')[-1].split()[0])
    if 'Magnet temperature:' in row:
        m_temp = float(row.split('Magnet temperature:')[-1].split()[0])
        #print (m_temp)
    if 'Winding temperature:' in row:
        w_temp = float(row.split('Winding temperature:')[-1].split()[0])
        #print (w_temp)
        # Very hard coded, but still a check
        if torque == 0 or m_temp == 0 or w_temp == 0:
            print ("Error in output!")
            exit (0)
        else:
            d['Torque'] += [torque]
            d['Magnet_Temp'] += [m_temp]
            d['Winding_Temp'] += [w_temp]
            torque = 0
            m_temp = 0
            w_temp = 0
        
df = pd.DataFrame(data=d)

df.plot()

df.to_excel('test.xlsx')




 
    